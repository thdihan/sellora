<?php $__env->startSection('content'); ?>
<style>
    .event-card {
        transition: all 0.3s ease;
        border-left: 4px solid #e9ecef;
    }
    .event-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }
    .event-type-badge {
        font-size: 0.75rem;
        padding: 0.25rem 0.5rem;
    }
    .priority-badge {
        font-size: 0.7rem;
        padding: 0.2rem 0.4rem;
    }
    .status-badge {
        font-size: 0.7rem;
        padding: 0.2rem 0.4rem;
    }
    .stats-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 1rem;
    }
    .stats-card.upcoming {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    .stats-card.today {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    .stats-card.completed {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
    }
    .filter-card {
        background: #f8f9fa;
        border-radius: 10px;
        padding: 1.5rem;
        margin-bottom: 2rem;
    }
    .event-time {
        font-size: 0.85rem;
        color: #6c757d;
    }
    .event-location {
        font-size: 0.8rem;
        color: #6c757d;
    }
</style>

<div class="container-fluid">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800">Events Calendar</h1>
            <p class="text-muted mb-0">Manage your events and schedule</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('events.calendar')); ?>" class="btn btn-outline-primary">
                📅 Calendar View
            </a>
            <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">
                Create Event
            </a>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="stats-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0"><?php echo e($stats['total']); ?></h4>
                        <small>Total Events</small>
                    </div>
                    <span style="font-size: 2rem; opacity: 0.75;">📅</span>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <a href="<?php echo e(route('events.upcoming')); ?>" class="text-decoration-none">
                <div class="stats-card upcoming">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="mb-0"><?php echo e($stats['upcoming']); ?></h4>
                            <small>Upcoming</small>
                        </div>
                        <span style="font-size: 2rem; opacity: 0.75;">🕒</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-3">
            <div class="stats-card today">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0"><?php echo e($stats['today']); ?></h4>
                        <small>Today</small>
                    </div>
                    <span style="font-size: 2rem; opacity: 0.75;">📅</span>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="stats-card completed">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0"><?php echo e($stats['completed']); ?></h4>
                        <small>Completed</small>
                    </div>
                    <span style="font-size: 2rem; opacity: 0.75;">✅</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="filter-card">
        <form method="GET" action="<?php echo e(route('events.index')); ?>" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Search</label>
                <input type="text" name="search" class="form-control" placeholder="Search events..." value="<?php echo e(request('search')); ?>">
            </div>
            <div class="col-md-2">
                <label class="form-label">Type</label>
                <select name="type" class="form-select">
                    <option value="">All Types</option>
                    <option value="meeting" <?php echo e(request('type') == 'meeting' ? 'selected' : ''); ?>>Meeting</option>
                    <option value="appointment" <?php echo e(request('type') == 'appointment' ? 'selected' : ''); ?>>Appointment</option>
                    <option value="deadline" <?php echo e(request('type') == 'deadline' ? 'selected' : ''); ?>>Deadline</option>
                    <option value="reminder" <?php echo e(request('type') == 'reminder' ? 'selected' : ''); ?>>Reminder</option>
                    <option value="personal" <?php echo e(request('type') == 'personal' ? 'selected' : ''); ?>>Personal</option>
                    <option value="holiday" <?php echo e(request('type') == 'holiday' ? 'selected' : ''); ?>>Holiday</option>
                    <option value="other" <?php echo e(request('type') == 'other' ? 'selected' : ''); ?>>Other</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="">All Status</option>
                    <option value="scheduled" <?php echo e(request('status') == 'scheduled' ? 'selected' : ''); ?>>Scheduled</option>
                    <option value="in_progress" <?php echo e(request('status') == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                    <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Completed</option>
                    <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
                    <option value="postponed" <?php echo e(request('status') == 'postponed' ? 'selected' : ''); ?>>Postponed</option>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Priority</label>
                <select name="priority" class="form-select">
                    <option value="">All Priorities</option>
                    <option value="low" <?php echo e(request('priority') == 'low' ? 'selected' : ''); ?>>Low</option>
                    <option value="medium" <?php echo e(request('priority') == 'medium' ? 'selected' : ''); ?>>Medium</option>
                    <option value="high" <?php echo e(request('priority') == 'high' ? 'selected' : ''); ?>>High</option>
                    <option value="urgent" <?php echo e(request('priority') == 'urgent' ? 'selected' : ''); ?>>Urgent</option>
                </select>
            </div>
            <div class="col-md-1">
                <label class="form-label">From</label>
                <input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>">
            </div>
            <div class="col-md-1">
                <label class="form-label">To</label>
                <input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>">
            </div>
            <div class="col-md-1 d-flex align-items-end">
                <button type="submit" class="btn btn-primary me-2">
                    🔍
                </button>
                <a href="<?php echo e(route('events.index')); ?>" class="btn btn-outline-secondary">
                    ❌
                </a>
            </div>
        </form>
    </div>

    <!-- Events List -->
    <?php if($events->count() > 0): ?>
        <div class="row">
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card event-card h-100" style="border-left-color: <?php echo e($event->getEventColor()); ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <h6 class="card-title mb-0"><?php echo e($event->title); ?></h6>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        ⋮
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="<?php echo e(route('events.show', $event)); ?>">👁️ View</a></li>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $event)): ?>
                                            <li><a class="dropdown-item" href="<?php echo e(route('events.edit', $event)); ?>">Edit</a></li>
                                        <?php endif; ?>
                                        <li><a class="dropdown-item" href="<?php echo e(route('events.duplicate', $event)); ?>">📋 Duplicate</a></li>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $event)): ?>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <form action="<?php echo e(route('events.destroy', $event)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this event?')">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="dropdown-item text-danger">
                                                        Delete
                                                    </button>
                                                </form>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="mb-2">
                                <span class="badge event-type-badge" style="background-color: <?php echo e($event->getEventColor()); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $event->event_type))); ?>

                                </span>
                                <span class="badge priority-badge 
                                    <?php if($event->priority == 'urgent'): ?> bg-danger
                                    <?php elseif($event->priority == 'high'): ?> bg-warning
                                    <?php elseif($event->priority == 'medium'): ?> bg-info
                                    <?php else: ?> bg-secondary
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst($event->priority)); ?>

                                </span>
                                <span class="badge status-badge 
                                    <?php if($event->status == 'completed'): ?> bg-success
                                    <?php elseif($event->status == 'in_progress'): ?> bg-primary
                                    <?php elseif($event->status == 'cancelled'): ?> bg-danger
                                    <?php elseif($event->status == 'postponed'): ?> bg-warning
                                    <?php else: ?> bg-secondary
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $event->status))); ?>

                                </span>
                            </div>
                            
                            <?php if($event->description): ?>
                                <p class="card-text text-muted small mb-2"><?php echo e(Str::limit($event->description, 80)); ?></p>
                            <?php endif; ?>
                            
                            <div class="event-time mb-1">
                                🕒
                                <?php echo e($event->formatted_start_date); ?>

                                <?php if(!$event->is_all_day && $event->start_time != $event->end_time): ?>
                                    - <?php echo e($event->formatted_end_date); ?>

                                <?php endif; ?>
                            </div>
                            
                            <?php if($event->location): ?>
                                <div class="event-location mb-2">
                                    📍
                                    <?php echo e($event->location); ?>

                                </div>
                            <?php endif; ?>
                            
                            <?php if($event->isRecurring()): ?>
                                <div class="text-muted small mb-2">
                                    🔄
                                    Recurring <?php echo e($event->recurring_type); ?>

                                </div>
                            <?php endif; ?>
                            
                            <?php if($event->attendees && is_array($event->attendees) && count($event->attendees) > 0): ?>
                                <div class="text-muted small mb-2">
                                    👥
                                    <?php echo e(is_array($event->attendees) ? count($event->attendees) : 0); ?> attendee(s)
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="card-footer bg-transparent">
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">
                                    <?php if($event->is_past): ?>
                                        📜 Past
                                    <?php elseif($event->is_today): ?>
                                        📅 Today
                                    <?php else: ?>
                                        📅 Upcoming
                                    <?php endif; ?>
                                </small>
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('events.show', $event)); ?>" class="btn btn-outline-primary btn-sm">
                                        👁️
                                    </a>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $event)): ?>
                                        <a href="<?php echo e(route('events.edit', $event)); ?>" class="btn btn-outline-secondary btn-sm">
                                            Edit
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?php if($events->hasPages()): ?>
                <?php echo e($events->appends(request()->query())->links('vendor.pagination.custom-3d')); ?>

            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <span style="font-size: 4rem;" class="text-muted mb-3">📅</span>
            <h4 class="text-muted">No Events Found</h4>
            <p class="text-muted mb-4">You haven't created any events yet or no events match your filters.</p>
            <a href="<?php echo e(route('events.create')); ?>" class="btn btn-primary">
                Create Your First Event
            </a>
        </div>
    <?php endif; ?>
</div>

<script>
// Auto-submit form on filter change
document.addEventListener('DOMContentLoaded', function() {
    const filterSelects = document.querySelectorAll('select[name="type"], select[name="status"], select[name="priority"]');
    const dateInputs = document.querySelectorAll('input[name="date_from"], input[name="date_to"]');
    
    filterSelects.forEach(select => {
        select.addEventListener('change', function() {
            this.form.submit();
        });
    });
    
    dateInputs.forEach(input => {
        input.addEventListener('change', function() {
            this.form.submit();
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/thdihan/Developer/Sellora/Sellora/sellora/resources/views/events/index.blade.php ENDPATH**/ ?>