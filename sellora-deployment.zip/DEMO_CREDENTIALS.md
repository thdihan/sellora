# Demo Credentials

Generated on: 2025-09-19 10:18:01

## User Accounts

| User | Role | Email | Password |
|------|------|-------|----------|
| Author (Owner) Demo | Author (Owner) | rayhand2k@gmail.com | [HIDDEN - Set INCLUDE_OWNER_PASSWORD_IN_OUTPUT=true to show] |
| Admin Demo | Admin | admin.demo@demo.local | re40X%<Z5,{ktM.$ |
| Chairman Demo | Chairman | chairman.demo@demo.local | y9tJ7KWp}kpsA>&F |
| Director Demo | Director | director.demo@demo.local | H0gp?|?TL<GTT;>t |
| ED Demo | ED | ed.demo@demo.local | -Y9an9qhua@3,m<P |
| GM Demo | GM | gm.demo@demo.local | 7a,Rng2%!PYYU0Ct |
| DGM Demo | DGM | dgm.demo@demo.local | voqX5E?3]3Tf8z#T |
| AGM Demo | AGM | agm.demo@demo.local | q8y+4Nz*eBjm#r6S |
| NSM Demo | NSM | nsm.demo@demo.local | ?N8QvX@8W0?(a8;o |
| ZSM Demo | ZSM | zsm.demo@demo.local | ,eqJ7Sq@iHO#:,=x |
| RSM Demo | RSM | rsm.demo@demo.local | Pdl*3h_hie36G]}> |
| ASM Demo | ASM | asm.demo@demo.local | 0S<+{sd#GTXRto6k |
| MPO Demo | MPO | mpo.demo@demo.local | TVs0Xaw8RH?Bdds; |
| MR Demo | MR | mr.demo@demo.local | *>EPX[1w&Hc}v=hR |
| Trainee Demo | Trainee | trainee.demo@demo.local | gAGFjL.<L1k%j*!O |

## Verification

### Login Verification Results

- ✅ Author (Owner): User exists with correct role assignment
- ✅ Admin: User exists with correct role assignment
- ✅ Chairman: User exists with correct role assignment
- ✅ Director: User exists with correct role assignment
- ✅ ED: User exists with correct role assignment
- ✅ GM: User exists with correct role assignment
- ✅ DGM: User exists with correct role assignment
- ✅ AGM: User exists with correct role assignment
- ✅ NSM: User exists with correct role assignment
- ✅ ZSM: User exists with correct role assignment
- ✅ RSM: User exists with correct role assignment
- ✅ ASM: User exists with correct role assignment
- ✅ MPO: User exists with correct role assignment
- ✅ MR: User exists with correct role assignment
- ✅ Trainee: User exists with correct role assignment

## Security Notes

- All passwords are randomly generated and unique
- Owner account is protected from deletion
- Demo data is safe to regenerate
- This file is excluded from version control
